package com.santubabu.nextplayerpro

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import dagger.hilt.android.AndroidEntryPoint
import com.santubabu.nextplayerpro.core.common.storagePermission
import com.santubabu.nextplayerpro.core.media.services.MediaService
import com.santubabu.nextplayerpro.core.media.sync.MediaSynchronizer
import com.santubabu.nextplayerpro.core.model.ThemeConfig
import com.santubabu.nextplayerpro.core.ui.theme.NextPlayerTheme
import com.santubabu.nextplayerpro.navigation.MediaRootRoute
import com.santubabu.nextplayerpro.navigation.mediaNavGraph
import com.santubabu.nextplayerpro.navigation.settingsNavGraph
import javax.inject.Inject
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var synchronizer: MediaSynchronizer

    @Inject
    lateinit var mediaService: MediaService

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {

        // Android 12+ splash screen (MUST be before super.onCreate)
        val splashScreen = installSplashScreen()

        super.onCreate(savedInstanceState)

        mediaService.initialize(this)

        var uiState: MainActivityUiState by mutableStateOf(MainActivityUiState.Loading)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { state ->
                    uiState = state
                }
            }
        }

        splashScreen.setKeepOnScreenCondition {
            uiState is MainActivityUiState.Loading
        }

        setContent {
            val shouldUseDarkTheme = shouldUseDarkTheme(uiState)

            LaunchedEffect(shouldUseDarkTheme) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(
                        lightScrim = Color.TRANSPARENT,
                        darkScrim = Color.TRANSPARENT,
                        detectDarkMode = { shouldUseDarkTheme },
                    ),
                    navigationBarStyle = SystemBarStyle.auto(
                        lightScrim = Color.TRANSPARENT,
                        darkScrim = Color.TRANSPARENT,
                        detectDarkMode = { shouldUseDarkTheme },
                    ),
                )
            }

            NextPlayerTheme(
                darkTheme = shouldUseDarkTheme,
                highContrastDarkTheme = shouldUseHighContrastDarkTheme(uiState),
                dynamicColor = shouldUseDynamicTheming(uiState),
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.surface,
                ) {
                    val storagePermissionState =
                        rememberPermissionState(permission = storagePermission)

                    LifecycleEventEffect(Lifecycle.Event.ON_START) {
                        storagePermissionState.launchPermissionRequest()
                    }

                    LaunchedEffect(storagePermissionState.status.isGranted) {
                        if (storagePermissionState.status.isGranted) {
                            synchronizer.startSync()
                        }
                    }

                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        startDestination = MediaRootRoute,
                        enterTransition = {
                            slideIntoContainer(
                                AnimatedContentTransitionScope.SlideDirection.Start,
                                tween(200, easing = LinearEasing),
                            )
                        },
                        exitTransition = {
                            slideOutOfContainer(
                                AnimatedContentTransitionScope.SlideDirection.Start,
                                tween(200, easing = LinearEasing),
                            )
                        },
                        popEnterTransition = {
                            slideIntoContainer(
                                AnimatedContentTransitionScope.SlideDirection.End,
                                tween(200, easing = LinearEasing),
                            )
                        },
                        popExitTransition = {
                            slideOutOfContainer(
                                AnimatedContentTransitionScope.SlideDirection.End,
                                tween(200, easing = LinearEasing),
                            )
                        },
                    ) {
                        mediaNavGraph(
                            context = this@MainActivity,
                            navController = navController,
                        )
                        settingsNavGraph(navController = navController)
                    }
                }
            }
        }
    }
}

/* -------------------- THEME HELPERS -------------------- */

@Composable
fun shouldUseDarkTheme(uiState: MainActivityUiState): Boolean =
    when (uiState) {
        MainActivityUiState.Loading -> isSystemInDarkTheme()
        is MainActivityUiState.Success -> when (uiState.preferences.themeConfig) {
            ThemeConfig.SYSTEM -> isSystemInDarkTheme()
            ThemeConfig.OFF -> false
            ThemeConfig.ON -> true
        }
    }

@Composable
fun shouldUseHighContrastDarkTheme(uiState: MainActivityUiState): Boolean =
    uiState is MainActivityUiState.Success &&
        uiState.preferences.useHighContrastDarkTheme

@Composable
fun shouldUseDynamicTheming(uiState: MainActivityUiState): Boolean =
    uiState is MainActivityUiState.Success &&
        uiState.preferences.useDynamicColors