package com.santubabu.nextplayerpro.core.model

enum class Resume {
    YES,
    NO,
}
