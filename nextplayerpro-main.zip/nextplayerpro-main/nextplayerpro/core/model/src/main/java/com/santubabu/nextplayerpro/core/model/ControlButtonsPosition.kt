package com.santubabu.nextplayerpro.core.model

enum class ControlButtonsPosition {
    LEFT,
    RIGHT,
}
