package com.santubabu.nextplayerpro.core.model

enum class VideoContentScale {
    BEST_FIT,
    STRETCH,
    CROP,
    HUNDRED_PERCENT,
}
