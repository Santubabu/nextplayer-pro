package com.santubabu.nextplayerpro.core.model

enum class DecoderPriority {
    PREFER_DEVICE,
    PREFER_APP,
    DEVICE_ONLY,
}
