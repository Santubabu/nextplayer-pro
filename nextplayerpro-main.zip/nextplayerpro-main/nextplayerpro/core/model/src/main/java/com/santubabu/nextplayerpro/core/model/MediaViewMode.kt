package com.santubabu.nextplayerpro.core.model

enum class MediaViewMode {
    FOLDER_TREE,
    FOLDERS,
    VIDEOS,
}
