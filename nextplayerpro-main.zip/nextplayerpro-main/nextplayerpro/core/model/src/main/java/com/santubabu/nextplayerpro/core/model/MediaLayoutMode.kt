package com.santubabu.nextplayerpro.core.model

enum class MediaLayoutMode {
    LIST,
    GRID,
}
