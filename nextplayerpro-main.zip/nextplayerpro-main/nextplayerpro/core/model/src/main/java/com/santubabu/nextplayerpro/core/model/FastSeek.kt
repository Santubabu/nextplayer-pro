package com.santubabu.nextplayerpro.core.model

enum class FastSeek {
    AUTO,
    ENABLE,
    DISABLE,
}
