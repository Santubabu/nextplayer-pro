package com.santubabu.nextplayerpro.core.model

enum class DoubleTapGesture {
    PLAY_PAUSE,
    FAST_FORWARD_AND_REWIND,
    BOTH,
    NONE,
}
