package com.santubabu.nextplayerpro.core.model

enum class Font {
    DEFAULT,
    MONOSPACE,
    SANS_SERIF,
    SERIF,
}
