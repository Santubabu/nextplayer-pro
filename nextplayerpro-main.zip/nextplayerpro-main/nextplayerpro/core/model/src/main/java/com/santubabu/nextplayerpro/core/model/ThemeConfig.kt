package com.santubabu.nextplayerpro.core.model

enum class ThemeConfig {
    SYSTEM,
    OFF,
    ON,
}
