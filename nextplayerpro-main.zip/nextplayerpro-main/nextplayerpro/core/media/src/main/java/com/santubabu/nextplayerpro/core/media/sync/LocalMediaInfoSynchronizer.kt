package com.santubabu.nextplayerpro.core.media.sync

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import dagger.hilt.android.qualifiers.ApplicationContext
import com.santubabu.nextplayerpro.core.common.Dispatcher
import com.santubabu.nextplayerpro.core.common.NextDispatchers
import com.santubabu.nextplayerpro.core.common.di.ApplicationScope
import com.santubabu.nextplayerpro.core.common.extensions.deleteFiles
import com.santubabu.nextplayerpro.core.common.extensions.thumbnailCacheDir
import com.santubabu.nextplayerpro.core.database.dao.MediumDao
import com.santubabu.nextplayerpro.core.database.entities.AudioStreamInfoEntity
import com.santubabu.nextplayerpro.core.database.entities.SubtitleStreamInfoEntity
import com.santubabu.nextplayerpro.core.database.entities.VideoStreamInfoEntity
import io.github.anilbeesetti.nextlib.mediainfo.AudioStream
import io.github.anilbeesetti.nextlib.mediainfo.MediaInfoBuilder
import io.github.anilbeesetti.nextlib.mediainfo.SubtitleStream
import io.github.anilbeesetti.nextlib.mediainfo.VideoStream
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import kotlin.text.substringBeforeLast
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class LocalMediaInfoSynchronizer @Inject constructor(
    private val mediumDao: MediumDao,
    @ApplicationScope private val applicationScope: CoroutineScope,
    @ApplicationContext private val context: Context,
    @Dispatcher(NextDispatchers.Default) private val dispatcher: CoroutineDispatcher,
) : MediaInfoSynchronizer {

    private val activeSyncJobs = mutableMapOf<String, Job>()
    private val mutex = Mutex()

    override fun sync(uri: Uri) {
        applicationScope.launch(dispatcher) {
            val uriString = uri.toString()

            mutex.withLock {
                activeSyncJobs[uriString]
            }?.join()

            val job = applicationScope.launch(dispatcher) {
                try {
                    performSync(uri)
                } finally {
                    mutex.withLock {
                        activeSyncJobs.remove(uriString)
                    }
                }
            }

            mutex.withLock {
                activeSyncJobs[uriString] = job
            }
        }
    }

    override suspend fun clearThumbnailsCache() = withContext(Dispatchers.IO) {
        activeSyncJobs.forEach { it.value.cancel() }
        context.thumbnailCacheDir.deleteFiles()
    }

    private suspend fun performSync(uri: Uri) {
        val medium = mediumDao.getWithInfo(uri.toString()) ?: return
        if (medium.mediumEntity.thumbnailPath?.let { File(it) }?.exists() == true) {
            return
        }

        val mediaInfo = runCatching {
            MediaInfoBuilder().from(context = context, uri = uri).build() ?: throw NullPointerException()
        }.onFailure { e ->
            e.printStackTrace()
            Log.d(TAG, "sync: MediaInfoBuilder exception", e)
        }.getOrNull() ?: return

        val mediaMetadataRetriever = MediaMetadataRetriever().apply {
            setDataSource(context, uri)
        }

        val thumbnail = runCatching {
            listOf(
                ".jpg",
                ".jpeg",
                ".png",
            ).firstOrNull { imageExtension ->
                File(medium.mediumEntity.path.substringBeforeLast(".") + ".$imageExtension").exists()
            }?.let {
                BitmapFactory.decodeFile(medium.mediumEntity.path.substringBeforeLast(".") + ".$it")
            }
        }.getOrNull()
            ?: runCatching { mediaMetadataRetriever.embeddedPicture?.toBitmap() }.getOrNull()
            ?: runCatching { mediaMetadataRetriever.getFrameAtTime(0) }.getOrNull()
            ?: runCatching { mediaInfo.getFrame() }.getOrNull()
        mediaInfo.release()
        mediaMetadataRetriever.release()

        val videoStreamInfo = mediaInfo.videoStream?.toVideoStreamInfoEntity(medium.mediumEntity.uriString)
        val audioStreamsInfo = mediaInfo.audioStreams.map {
            it.toAudioStreamInfoEntity(medium.mediumEntity.uriString)
        }
        val subtitleStreamsInfo = mediaInfo.subtitleStreams.map {
            it.toSubtitleStreamInfoEntity(medium.mediumEntity.uriString)
        }
        val thumbnailPath = thumbnail?.saveTo(
            storageDir = context.thumbnailCacheDir,
            quality = 40,
            fileName = medium.mediumEntity.mediaStoreId.toString(),
        )

        mediumDao.upsert(
            medium.mediumEntity.copy(
                format = mediaInfo.format,
                thumbnailPath = thumbnailPath,
            ),
        )
        videoStreamInfo?.let { mediumDao.upsertVideoStreamInfo(it) }
        audioStreamsInfo.onEach { mediumDao.upsertAudioStreamInfo(it) }
        subtitleStreamsInfo.onEach { mediumDao.upsertSubtitleStreamInfo(it) }
    }

    companion object {
        private const val TAG = "MediaInfoSynchronizer"
    }
}

private fun VideoStream.toVideoStreamInfoEntity(mediumUri: String) = VideoStreamInfoEntity(
    index = index,
    title = title,
    codecName = codecName,
    language = language,
    disposition = disposition,
    bitRate = bitRate,
    frameRate = frameRate,
    frameWidth = frameWidth,
    frameHeight = frameHeight,
    mediumUri = mediumUri,
)

private fun AudioStream.toAudioStreamInfoEntity(mediumUri: String) = AudioStreamInfoEntity(
    index = index,
    title = title,
    codecName = codecName,
    language = language,
    disposition = disposition,
    bitRate = bitRate,
    sampleFormat = sampleFormat,
    sampleRate = sampleRate,
    channels = channels,
    channelLayout = channelLayout,
    mediumUri = mediumUri,
)

private fun SubtitleStream.toSubtitleStreamInfoEntity(mediumUri: String) = SubtitleStreamInfoEntity(
    index = index,
    title = title,
    codecName = codecName,
    language = language,
    disposition = disposition,
    mediumUri = mediumUri,
)

suspend fun Bitmap.saveTo(
    storageDir: File,
    quality: Int = 100,
    fileName: String,
): String? = withContext(Dispatchers.IO) {
    val thumbFile = File(storageDir, fileName)
    try {
        FileOutputStream(thumbFile).use { fos ->
            compress(Bitmap.CompressFormat.JPEG, quality, fos)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return@withContext if (thumbFile.exists()) thumbFile.path else null
}

fun ByteArray.toBitmap(): Bitmap? {
    return BitmapFactory.decodeByteArray(this, 0, this.size)
}
